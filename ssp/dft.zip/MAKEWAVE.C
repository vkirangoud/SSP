/*______________________________________________________________________
MAKEWAVE.C		Test Signal Generator for Floating Point Data

Revision: 2.0, 18-FEB-91, Steven Cox, Analog Devices
______________________________________________________________________*/

/* Includes Random numbers */
#include <stdio.h>
#include <math.h>
double x[4196];  /*made global for a huge array*/
main()
{
  int i, j, n, num_sines, pstart, plength;
  float amplitude, freq;
  double pi;
  FILE *out_file;
  char filename[25], s_c_p;

  printf("%c%c%c%c",27,91,50,74); /*clear screen*/
  printf("%c%c%c",27,91,72);      /*curser home*/
  printf("_________Test Signal Generator for Floating Point Data_________\n");
  printf("Generates a floating point test data file of summed sines,\n");
  printf("cosines, pulses and random data. This can be used to test\n");
  printf("ADSP-21020 FFT code and to generate Sine and Cosine arrays.\n");
  printf("Version 2.0, 18-FEB-91, Steven Cox, Analog Devices\n");
  printf("_______________________________________________________________\n");

  printf("\nEnter the output filename -------------> ");
  scanf(" %s",filename);
  out_file=fopen(filename,"w");

  printf("Enter the number of points (max 4196) -> ");
  scanf(" %d",&n);

  printf("Enter the number of waveforms to add --> ");
  scanf(" %d",&num_sines);

  pi=3.141592654;
            /*clear accumulator*/
  for (i=0; i <= n-1; i++)
    {
      x[i]=0.0;
    }

           /*sum up all signals together*/
  for (j=1; j <= num_sines; j++)
    {
      printf("\nWave #%d (S)ine, (C)osine, (P)ulse or (R)andom ? ",j);
      scanf(" %c",&s_c_p);
      printf("Wave #%d Enter amplitude ---------------> ",j);
      scanf(" %f",&amplitude);

      if(s_c_p == 's' || s_c_p == 'S')
        {
          printf("Wave #%d Enter frequency bin (0 to %d) -> ",j,n-1);
          scanf(" %f",&freq);
          for (i=0; i <= n-1; i++)
            {
              x[i]=x[i]+( amplitude*sin(2.0*pi*(double)i*freq/(double)n) );
            }
        }
      else if(s_c_p == 'c' || s_c_p == 'C')
        {
          printf("Wave #%d Enter frequency bin (0 to %d) -> ",j,n-1);
          scanf(" %f",&freq);
          for (i=0; i <= n-1; i++)
            {
              x[i]=x[i]+( amplitude*cos(2.0*pi*(double)i*freq/(double)n) );
            }
        }
      else if(s_c_p == 'p' || s_c_p == 'P')
        {
          printf("Wave #%d Enter pulse start bin (0 to %d) -> ",j,n-1);
          scanf(" %d",&pstart);
          printf("Wave #%d Enter pulse length (1 to %d) -> ",j,n-pstart);
          scanf(" %d",&plength);
          for (i=pstart; i <= pstart+plength-1; i++)
            {
              x[i]=x[i]+amplitude;
            }
        }
      else if(s_c_p == 'r' || s_c_p == 'R')
        {
          for (i=0; i <= n-1; i++)
            {
              x[i]=x[i]+amplitude*((rand()-16384.0)/16384.0)*(rand()/32767.0);
            }
        }
      else
        printf("Not S,C,P or R. You wasted that wave\n");
    } /*end j*/

            /*write results*/
  printf("\n");
  for (i=0; i <= n-1; i++)
    {
      fprintf(out_file,"%15.10e\n",x[i]);
      printf("%d : %15.10e\r",i,x[i]);

    }
  fclose(out_file);
  printf("\nFinished\n");
}
